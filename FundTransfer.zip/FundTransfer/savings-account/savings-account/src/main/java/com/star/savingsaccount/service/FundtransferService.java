/**
 * 
 */
package com.star.savingsaccount.service;

import com.star.savingsaccount.entity.TransactionHistory;
import com.star.savingsaccount.exception.TransactionException;

/**
 * @author User1
 *
 */
public interface FundtransferService {

	/**
	 * @param transactionHistory
	 * @throws FundTransferException
	 */
	public void fundTransfer(TransactionHistory transactionHistory) throws TransactionException;

}
