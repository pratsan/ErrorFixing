/**
 * 
 */
package com.star.savingsaccount.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.star.savingsaccount.dto.BenificiaryAccountDto;
import com.star.savingsaccount.dto.ResponseDto;
import com.star.savingsaccount.service.BenificiaryAccountService;

/**
 * @author uma
 *
 */

@RestController
public class BeneficiaryAccountController {
	
	@Autowired
	BenificiaryAccountService benificiaryAccountService;
	
	
	
	@PostMapping("benificiary/register")
	public ResponseEntity<ResponseDto> beneficiaryRegistration(
	@RequestBody BenificiaryAccountDto benificiaryAccountDto) {
	ResponseDto responseDto = benificiaryAccountService.beneficiaryRegistration(benificiaryAccountDto);
	return new ResponseEntity<>(responseDto, HttpStatus.OK);

	}

	

}
