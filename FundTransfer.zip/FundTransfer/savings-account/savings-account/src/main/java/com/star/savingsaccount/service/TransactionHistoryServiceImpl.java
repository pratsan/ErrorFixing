/**
 * 
 */
package com.star.savingsaccount.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.star.savingsaccount.dto.HistoryReqDto;
import com.star.savingsaccount.dto.HistoryRespDto;
import com.star.savingsaccount.dto.TransactionHistoryDto;
import com.star.savingsaccount.entity.TransactionHistory;
import com.star.savingsaccount.entity.User;
import com.star.savingsaccount.exception.TransactionException;
import com.star.savingsaccount.repository.TransactionHistoryRepository;
import com.star.savingsaccount.repository.UserRepository;

/**
 * @author User1
 *
 */

@Service
public class TransactionHistoryServiceImpl implements TransactionHistoryService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	TransactionHistoryRepository transactionHistoryRepository;

	@Override
	public HistoryRespDto transactionHistory(Long userId, HistoryReqDto historyReqDto) throws TransactionException {

		HistoryRespDto historyRespDto = new HistoryRespDto();
		Optional<User> userOpt = userRepository.findById(userId);

		if (!userOpt.isPresent()) {
			throw new TransactionException("Status Code: 404");
		} else {
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			Date fmDate;
			try {
				fmDate = format.parse(historyReqDto.getFromDate());
				Date toDate = format.parse(historyReqDto.getTodate());
				List<TransactionHistory> transactionHistoryList = transactionHistoryRepository
						.findByIdAndTransactionDate(userId, fmDate, toDate);

				User user = userOpt.get();
				// Set all the user details now

				historyRespDto.setAccountNumber(
						user.getUserAccount() != null ? user.getUserAccount().getAccountNumber() : "");
				historyRespDto.setUserName(user.getName());
				historyRespDto.setAddress(user.getUserAdress());
				historyRespDto.setBalance(user.getUserAccount().getAvailableBalance());
				historyRespDto.setBranch(user.getUserAccount().getBranchName());

				List<TransactionHistoryDto> trxDtos = new ArrayList<TransactionHistoryDto>();
				for (TransactionHistory trxHistory : transactionHistoryList) {

					TransactionHistoryDto dto = new TransactionHistoryDto();
					dto.setAmount(trxHistory.getAmount());
					dto.setNarration(trxHistory.getNarration());
					dto.setRefNumber(trxHistory.getRefNumber());
					dto.setTransactionType(trxHistory.getTransactionType());
					DateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");  
					String strDate = dateFormat.format(trxHistory.getTransactionDate()); 
					dto.setDate(strDate);
					trxDtos.add(dto);
				}
				historyRespDto.setTransactionHistoryDto(trxDtos);

			} catch (ParseException e) {
				e.printStackTrace();
			}
		}

		return historyRespDto;

	}

}
